
  # Create Simple Game Design

  This is a code bundle for Create Simple Game Design. The original project is available at https://www.figma.com/design/mVyUwl8w4fpnXdeIFrrKAl/Create-Simple-Game-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  