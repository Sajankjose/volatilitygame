// Sound utility for game audio effects
class SoundManager {
  private audioContext: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.masterGain = this.audioContext.createGain();
      this.masterGain.connect(this.audioContext.destination);
      this.masterGain.gain.value = 0.3; // Default volume at 30%
    }
  }

  private playTone(frequency: number, duration: number, type: OscillatorType = 'sine', volume: number = 1) {
    if (!this.audioContext || !this.masterGain || this.isMuted) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.frequency.value = frequency;
    oscillator.type = type;

    gainNode.gain.setValueAtTime(volume * 0.3, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  // Button click - subtle and professional
  playClick() {
    this.playTone(800, 0.1, 'sine', 0.4);
  }

  // Hold button - reassuring tone
  playHold() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(600, 0.15, 'sine', 0.5);
    setTimeout(() => this.playTone(650, 0.1, 'sine', 0.3), 50);
  }

  // Invest More - positive, uplifting
  playInvest() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(600, 0.1, 'sine', 0.5);
    setTimeout(() => this.playTone(800, 0.1, 'sine', 0.5), 80);
    setTimeout(() => this.playTone(1000, 0.15, 'sine', 0.6), 160);
  }

  // Exit - neutral warning tone
  playExit() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(400, 0.2, 'sine', 0.5);
    setTimeout(() => this.playTone(350, 0.2, 'sine', 0.4), 100);
  }

  // Market drop event - descending tone
  playMarketDrop() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(700, 0.15, 'sine', 0.4);
    setTimeout(() => this.playTone(500, 0.15, 'sine', 0.4), 100);
  }

  // Market rise event - ascending tone
  playMarketRise() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(500, 0.15, 'sine', 0.4);
    setTimeout(() => this.playTone(700, 0.15, 'sine', 0.4), 100);
  }

  // Volatility event - rapid alternating
  playVolatility() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(600, 0.1, 'square', 0.3);
    setTimeout(() => this.playTone(650, 0.1, 'square', 0.3), 80);
  }

  // Success - celebratory fanfare
  playSuccess() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(523, 0.15, 'sine', 0.6); // C
    setTimeout(() => this.playTone(659, 0.15, 'sine', 0.6), 150); // E
    setTimeout(() => this.playTone(784, 0.15, 'sine', 0.6), 300); // G
    setTimeout(() => this.playTone(1047, 0.3, 'sine', 0.7), 450); // C (higher)
  }

  // Progress tick - subtle feedback
  playProgressTick() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(1200, 0.05, 'sine', 0.2);
  }

  // Start game
  playStart() {
    if (!this.audioContext || this.isMuted) return;
    this.playTone(400, 0.1, 'sine', 0.5);
    setTimeout(() => this.playTone(600, 0.1, 'sine', 0.5), 100);
    setTimeout(() => this.playTone(800, 0.2, 'sine', 0.6), 200);
  }

  setMuted(muted: boolean) {
    this.isMuted = muted;
    if (typeof window !== 'undefined') {
      localStorage.setItem('gameMuted', muted.toString());
    }
  }

  isMutedState(): boolean {
    return this.isMuted;
  }

  loadMutedState() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('gameMuted');
      this.isMuted = saved === 'true';
    }
  }
}

export const soundManager = new SoundManager();
