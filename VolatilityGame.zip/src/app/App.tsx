import { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { IntroScreen } from './components/IntroScreen';
import { InstructionsScreen } from './components/InstructionsScreen';
import { GameplayScreen } from './components/GameplayScreen';
import { ResultScreen } from './components/ResultScreen';
import { ShareCard } from './components/ShareCard';

type Screen = 'intro' | 'instructions' | 'gameplay' | 'result';

interface GameResult {
  units: number;
  timeInvested: number;
  exited: boolean;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('intro');
  const [gameResult, setGameResult] = useState<GameResult>({
    units: 0,
    timeInvested: 0,
    exited: false,
  });
  const [showShareCard, setShowShareCard] = useState(false);

  const handleStartFromIntro = () => {
    setCurrentScreen('instructions');
  };

  const handleStartGame = () => {
    setCurrentScreen('gameplay');
  };

  const handleGameEnd = (units: number, timeInvested: number, exited: boolean) => {
    setGameResult({ units, timeInvested, exited });
    setCurrentScreen('result');
  };

  const handlePlayAgain = () => {
    setCurrentScreen('intro');
  };

  const handleShare = () => {
    setShowShareCard(true);
  };

  const handleCloseShare = () => {
    setShowShareCard(false);
  };

  return (
    <div className="min-h-screen max-w-[390px] mx-auto bg-[#F7F9FA] relative overflow-hidden">
      <AnimatePresence mode="wait">
        {currentScreen === 'intro' && (
          <IntroScreen key="intro" onStart={handleStartFromIntro} />
        )}
        {currentScreen === 'instructions' && (
          <InstructionsScreen key="instructions" onStart={handleStartGame} />
        )}
        {currentScreen === 'gameplay' && (
          <GameplayScreen key="gameplay" onGameEnd={handleGameEnd} />
        )}
        {currentScreen === 'result' && (
          <ResultScreen
            key="result"
            units={gameResult.units}
            timeInvested={gameResult.timeInvested}
            exited={gameResult.exited}
            onPlayAgain={handlePlayAgain}
            onShare={handleShare}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showShareCard && (
          <ShareCard
            key="share"
            units={gameResult.units}
            timeInvested={gameResult.timeInvested}
            exited={gameResult.exited}
            onClose={handleCloseShare}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
