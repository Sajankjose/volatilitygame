import { motion } from 'motion/react';
import { TrendingUp } from 'lucide-react';

interface IntroScreenProps {
  onStart: () => void;
}

export function IntroScreen({ onStart }: IntroScreenProps) {
  return (
    <div className="h-screen flex flex-col justify-between p-6 bg-[#F7F9FA]">
      <motion.div
        className="flex-1 flex flex-col justify-center items-center text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <motion.h1
          className="text-[28px] font-bold text-[#1A1A1A] mb-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          Ride the Market
        </motion.h1>
        <motion.p
          className="text-[16px] text-[#6B7280] mb-12 max-w-[280px]"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          Experience how investors navigate market volatility.
        </motion.p>

        {/* Minimal Illustration */}
        <motion.div
          className="relative w-64 h-64 mb-12"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          {/* Wave pattern */}
          <svg
            viewBox="0 0 256 256"
            className="w-full h-full"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Background waves */}
            <motion.path
              d="M 10 180 Q 64 100, 128 140 T 246 120"
              fill="none"
              stroke="#0B6E69"
              strokeWidth="2"
              opacity="0.2"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: 0.6, duration: 1.5, ease: "easeInOut" }}
            />
            <motion.path
              d="M 10 160 Q 64 80, 128 120 T 246 100"
              fill="none"
              stroke="#0B6E69"
              strokeWidth="2"
              opacity="0.3"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: 0.7, duration: 1.5, ease: "easeInOut" }}
            />
            
            {/* Main chart line */}
            <motion.path
              d="M 10 140 Q 64 60, 128 100 T 246 80"
              fill="none"
              stroke="#0B6E69"
              strokeWidth="3"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: 0.8, duration: 1.5, ease: "easeInOut" }}
            />

            {/* Investor riding icon */}
            <motion.g
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5, duration: 0.5 }}
            >
              <circle cx="200" cy="85" r="6" fill="#F4B400" />
              <TrendingUp
                x="185"
                y="70"
                size={30}
                className="text-[#0B6E69]"
              />
            </motion.g>
          </svg>
        </motion.div>
      </motion.div>

      <motion.button
        onClick={onStart}
        className="w-full h-[52px] bg-[#0B6E69] text-white rounded-full text-[16px] font-semibold shadow-sm hover:bg-[#095b57] transition-colors"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Start the Experience
      </motion.button>

      <motion.p
        className="text-[12px] text-[#6B7280] text-center mt-4 leading-relaxed"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.6 }}
      >
        For educational illustration only. Market investments are subject to risk.
        Past performance does not guarantee future returns.
      </motion.p>
    </div>
  );
}
