import { motion } from 'motion/react';
import { X, Download } from 'lucide-react';

interface ShareCardProps {
  units: number;
  timeInvested: number;
  exited: boolean;
  onClose: () => void;
}

export function ShareCard({ units, timeInvested, exited, onClose }: ShareCardProps) {
  return (
    <motion.div
      className="fixed inset-0 flex items-center justify-center p-6 bg-black bg-opacity-50 z-50"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="bg-[#F7F9FA] rounded-3xl p-6 shadow-2xl max-w-md w-full"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-[18px] font-semibold text-[#1A1A1A]">Share Your Result</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5 text-[#6B7280]" />
          </button>
        </div>

        {/* Share Card Design */}
        <div
          id="share-card"
          className="aspect-square bg-gradient-to-br from-[#0B6E69] to-[#16A34A] rounded-3xl p-8 flex flex-col justify-between text-white mb-6"
        >
          <div>
            <h3 className="text-[24px] font-bold mb-2">Ride the Market</h3>
            <div className="w-12 h-1 bg-[#F4B400] rounded-full"></div>
          </div>

          <div className="space-y-4">
            <p className="text-[18px] leading-relaxed">
              {exited
                ? `I learned about market volatility by staying invested for ${timeInvested} seconds.`
                : `I stayed invested through volatility and reached the wealth goal with ${units.toFixed(2)} units!`}
            </p>
            <div className="flex gap-4 text-[14px] opacity-90">
              <div>
                <p className="font-semibold">{timeInvested}s</p>
                <p>Invested</p>
              </div>
              <div>
                <p className="font-semibold">{units.toFixed(2)}</p>
                <p>Units</p>
              </div>
            </div>
          </div>

          <div>
            <p className="text-[14px] opacity-90 mb-4">
              Learn how disciplined investing works.
            </p>
            <div className="flex items-center gap-2">
              
              <span className="text-[12px] opacity-75">Geojit Financial Services</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            // In a real app, this would trigger download/share functionality
            alert('Share functionality would be implemented here!');
          }}
          className="w-full h-[52px] bg-[#0B6E69] text-white rounded-full text-[16px] font-semibold shadow-sm hover:bg-[#095b57] transition-colors flex items-center justify-center gap-2"
        >
          <Download className="w-5 h-5" />
          Download Card
        </button>
      </motion.div>
    </motion.div>
  );
}