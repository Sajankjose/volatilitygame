import { motion } from 'motion/react';
import { Trophy, TrendingUp, Clock, Package, Share2, Crown, Medal } from 'lucide-react';

interface ResultScreenProps {
  units: number;
  timeInvested: number;
  exited: boolean;
  onPlayAgain: () => void;
  onShare: () => void;
}

export function ResultScreen({
  units,
  timeInvested,
  exited,
  onPlayAgain,
  onShare,
}: ResultScreenProps) {
  const isSuccess = !exited && units >= 20;
  
  // Calculate user's portfolio value (assuming NAV fluctuated)
  const avgNAV = 100;
  const portfolioValue = units * avgNAV;
  const profitPercent = ((units - 10) / 10) * 100;

  // Randomly place user in 2nd or 3rd position
  const userRank = Math.random() < 0.5 ? 2 : 3;
  
  // Generate better performers (above user)
  const betterPerformers = [];
  for (let i = 1; i < userRank; i++) {
    const bonusUnits = (userRank - i + 1) * 5 + Math.random() * 5;
    const topUnits = units + bonusUnits;
    const topValue = topUnits * avgNAV;
    const topProfit = ((topUnits - 10) / 10) * 100;
    
    betterPerformers.push({
      rank: i,
      name: i === 1 ? 'Rajesh K.' : 'Priya M.',
      units: topUnits,
      value: topValue,
      profit: topProfit,
    });
  }

  // Generate worse performers (below user)
  const worsePerformers = [];
  const names = ['Amit S.', 'Sneha R.', 'Vikram T.', 'Neha P.'];
  for (let i = userRank + 1; i <= 6; i++) {
    const penalty = (i - userRank) * 3 + Math.random() * 3;
    const lowerUnits = Math.max(10, units - penalty);
    const lowerValue = lowerUnits * avgNAV;
    const lowerProfit = ((lowerUnits - 10) / 10) * 100;
    
    worsePerformers.push({
      rank: i,
      name: names[i - userRank - 1],
      units: lowerUnits,
      value: lowerValue,
      profit: lowerProfit,
    });
  }

  // Mock leaderboard data with user at 2nd or 3rd
  const leaderboardData = [
    ...betterPerformers,
    { rank: userRank, name: 'You', units: units, value: portfolioValue, profit: profitPercent },
    ...worsePerformers,
  ];

  return (
    <div className="h-screen flex flex-col bg-[#F7F9FA] p-6 overflow-hidden">
      <div className="flex-1 overflow-y-auto pb-4">
        <motion.div
          className="text-center mt-8 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="w-20 h-20 bg-gradient-to-br from-[#0B6E69] to-[#16A34A] rounded-full flex items-center justify-center mx-auto mb-4"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          >
            <Trophy className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-[28px] font-bold text-[#1A1A1A] mb-2">
            Your Market Journey
          </h1>
        </motion.div>

        {/* Summary Card */}
        <motion.div
          className="bg-white rounded-3xl p-6 shadow-sm mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F7F9FA] rounded-full flex items-center justify-center">
                  <Clock className="w-5 h-5 text-[#0B6E69]" />
                </div>
                <div>
                  <p className="text-[14px] text-[#6B7280]">Time Stayed Invested</p>
                  <p className="text-[18px] font-semibold text-[#1A1A1A]">
                    {timeInvested} seconds
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pb-4 border-b border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F7F9FA] rounded-full flex items-center justify-center">
                  <Package className="w-5 h-5 text-[#0B6E69]" />
                </div>
                <div>
                  <p className="text-[14px] text-[#6B7280]">Units Purchased</p>
                  <p className="text-[18px] font-semibold text-[#1A1A1A]">{units.toFixed(2)} units</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F7F9FA] rounded-full flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-[#0B6E69]" />
                </div>
                <div>
                  <p className="text-[14px] text-[#6B7280]">Final Outcome</p>
                  <p className="text-[18px] font-semibold text-[#1A1A1A]">
                    {exited ? 'Exited Early' : 'Completed Journey'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-[16px] text-[#1A1A1A] leading-relaxed">
              {exited
                ? `You exited the market early after ${timeInvested} seconds. Staying invested could have yielded better results.`
                : `You stayed invested through volatility and accumulated ${units.toFixed(2)} units. Well done!`}
            </p>
          </div>
        </motion.div>

        {/* Key Learning Card */}
        <motion.div
          className="bg-gradient-to-br from-[#0B6E69] to-[#16A34A] rounded-3xl p-6 text-white mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <p className="text-[14px] opacity-90 mb-2 font-semibold">Key Learning</p>
          <p className="text-[16px] leading-relaxed">
            Market volatility rewards disciplined investors who stay the course.
          </p>
        </motion.div>

        {/* Leaderboard Card */}
        <motion.div
          className="bg-white rounded-3xl p-5 shadow-sm mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[18px] font-bold text-[#1A1A1A]">Leaderboard</h2>
            <div className="bg-[#F7F9FA] px-3 py-1 rounded-full">
              <p className="text-[12px] font-semibold text-[#0B6E69]">Rank #{userRank}</p>
            </div>
          </div>
          
          <div className="space-y-2">
            {leaderboardData.map((player, index) => {
              const isUser = player.name === 'You';
              return (
                <div
                  key={index}
                  className={`flex items-center justify-between p-3 rounded-xl ${
                    isUser ? 'bg-gradient-to-r from-[#F4B400]/10 to-[#F4B400]/5 border-2 border-[#F4B400]' : 'bg-[#F7F9FA]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm">
                      {player.rank === 1 ? (
                        <Crown className="w-4 h-4 text-[#FFD700]" />
                      ) : player.rank === 2 ? (
                        <Medal className="w-4 h-4 text-[#C0C0C0]" />
                      ) : player.rank === 3 ? (
                        <Medal className="w-4 h-4 text-[#CD7F32]" />
                      ) : (
                        <span className="text-[12px] font-bold text-[#0B6E69]">{player.rank}</span>
                      )}
                    </div>
                    <div>
                      <p className={`text-[14px] font-semibold ${isUser ? 'text-[#F4B400]' : 'text-[#1A1A1A]'}`}>
                        {player.name}
                      </p>
                      <p className="text-[11px] text-[#6B7280]">{player.units.toFixed(2)} units</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[14px] font-bold text-[#16A34A]">₹{player.value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    <p className="text-[11px] text-[#6B7280]">+{player.profit.toFixed(2)}%</p>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* Action Buttons */}
      <motion.div
        className="space-y-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.6 }}
      >
        <button
          onClick={onPlayAgain}
          className="w-full h-[52px] bg-[#0B6E69] text-white rounded-full text-[16px] font-semibold shadow-sm hover:bg-[#095b57] transition-colors"
        >
          Play Again
        </button>
        <button
          onClick={onShare}
          className="w-full h-[52px] bg-white border-2 border-[#0B6E69] text-[#0B6E69] rounded-full text-[16px] font-semibold shadow-sm hover:bg-[#F7F9FA] transition-colors flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" />
          Share Result
        </button>
        <a 
          href="https://www.geojit.com/campaigns/volatilitylab/marketscenarios.html" 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-full h-[52px] bg-white text-[#0B6E69] rounded-full text-[16px] font-semibold shadow-sm hover:bg-[#F7F9FA] transition-colors flex items-center justify-center"
        >
          Explore SIP Investing
        </a>
      </motion.div>
    </div>
  );
}