import { motion } from 'motion/react';
import { TrendingDown, Heart, Target } from 'lucide-react';

interface InstructionsScreenProps {
  onStart: () => void;
}

export function InstructionsScreen({ onStart }: InstructionsScreenProps) {
  const instructions = [
    {
      icon: <TrendingDown className="w-8 h-8 text-[#0B6E69]" />,
      text: 'Markets move up and down.',
    },
    {
      icon: <Heart className="w-8 h-8 text-[#0B6E69]" />,
      text: 'Stay calm and continue investing.',
    },
    {
      icon: <Target className="w-8 h-8 text-[#0B6E69]" />,
      text: 'Reach the long-term wealth goal.',
    },
  ];

  return (
    <div className="h-screen flex flex-col justify-between p-6 bg-[#F7F9FA]">
      <div className="flex-1 flex flex-col">
        <motion.h1
          className="text-[28px] font-bold text-[#1A1A1A] mb-8 text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          How to Play
        </motion.h1>

        <div className="flex-1 flex flex-col justify-center space-y-6">
          {instructions.map((instruction, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + index * 0.15, duration: 0.5 }}
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-[#F7F9FA] rounded-full flex items-center justify-center">
                  {instruction.icon}
                </div>
                <p className="text-[16px] text-[#1A1A1A] flex-1 mt-2">
                  {instruction.text}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <motion.button
        onClick={onStart}
        className="w-full h-[52px] bg-[#0B6E69] text-white rounded-full text-[16px] font-semibold shadow-sm hover:bg-[#095b57] transition-colors"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.6 }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Start Game
      </motion.button>
    </div>
  );
}
