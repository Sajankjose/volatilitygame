import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, TrendingUp, IndianRupee, Target, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { soundManager } from '../utils/sounds';

interface MarketEvent {
  id: number;
  type: 'drop' | 'rise' | 'volatility';
  title: string;
  message: string;
}

interface GameplayScreenProps {
  onGameEnd: (units: number, timeInvested: number, exited: boolean) => void;
}

export function GameplayScreen({ onGameEnd }: GameplayScreenProps) {
  const [units, setUnits] = useState(10);
  const [time, setTime] = useState(0);
  const [progress, setProgress] = useState(0);
  const [currentEvent, setCurrentEvent] = useState<MarketEvent | null>(null);
  const [gameActive, setGameActive] = useState(true);
  const [nav, setNav] = useState(100); // Starting NAV at ₹100
  const [investedAmount, setInvestedAmount] = useState(1000); // 10 units × ₹100
  const [showTutorial, setShowTutorial] = useState(true);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [holdActionsLeft, setHoldActionsLeft] = useState(6); // Limited Hold actions
  const [investActionsLeft, setInvestActionsLeft] = useState(5); // Limited Invest actions
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const marketPathRef = useRef<number[]>([]);

  // Load muted state on mount
  useEffect(() => {
    soundManager.loadMutedState();
    setIsMuted(soundManager.isMutedState());
  }, []);

  const events: MarketEvent[] = [
    {
      id: 1,
      type: 'drop',
      title: '📉 Market Drop',
      message: 'Stay calm! Successful investors don\'t panic sell.',
    },
    {
      id: 2,
      type: 'rise',
      title: '📈 Market Rally',
      message: 'Great! Staying invested is paying off.',
    },
    {
      id: 3,
      type: 'volatility',
      title: '⚡ Volatility Alert',
      message: 'Markets fluctuate. Long-term investing wins!',
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      if (gameActive && !showTutorial) {
        setTime((prev) => prev + 1);
        setProgress((prev) => Math.min(prev + 2.5, 100));

        // Trigger random events
        if (Math.random() < 0.15 && !currentEvent) {
          const randomEvent = events[Math.floor(Math.random() * events.length)];
          setCurrentEvent(randomEvent);
          
          // Play event sound
          if (randomEvent.type === 'drop') {
            soundManager.playMarketDrop();
          } else if (randomEvent.type === 'rise') {
            soundManager.playMarketRise();
          } else if (randomEvent.type === 'volatility') {
            soundManager.playVolatility();
          }
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [gameActive, currentEvent, showTutorial]);

  // Auto-dismiss events after 4 seconds
  useEffect(() => {
    if (currentEvent) {
      const timeout = setTimeout(() => {
        setCurrentEvent(null);
      }, 4000);

      return () => clearTimeout(timeout);
    }
  }, [currentEvent]);

  // Auto-dismiss feedback after 2 seconds
  useEffect(() => {
    if (actionFeedback) {
      const timeout = setTimeout(() => {
        setActionFeedback(null);
      }, 2000);

      return () => clearTimeout(timeout);
    }
  }, [actionFeedback]);

  useEffect(() => {
    if (progress >= 100 && gameActive) {
      soundManager.playSuccess();
      setGameActive(false);
      setTimeout(() => {
        onGameEnd(units, time, false);
      }, 500);
    }
  }, [progress, gameActive, units, time, onGameEnd]);

  // Draw animated market chart
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    let animationFrame: number;

    // Generate realistic market data points
    const generateMarketPath = () => {
      const points = 60;
      const path = [];
      let value = 0.5; // Start at middle
      
      for (let i = 0; i < points; i++) {
        // Add trending behavior with volatility
        const trend = Math.sin(i * 0.05) * 0.02; // Slow trend changes
        const volatility = (Math.random() - 0.5) * 0.08; // Random movements
        const momentum = i > 0 ? (value - (path[i - 1] || 0.5)) * 0.3 : 0; // Carry momentum
        
        value += trend + volatility + momentum;
        value = Math.max(0.2, Math.min(0.8, value)); // Keep within bounds
        path.push(value);
      }
      return path;
    };

    const marketPath = generateMarketPath();
    marketPathRef.current = marketPath;

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw background grid
      ctx.strokeStyle = '#E5E7EB';
      ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) {
        const y = (height / 4) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw smooth market path using quadratic curves
      ctx.strokeStyle = '#0B6E69';
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();

      const points = marketPath.length;
      const segmentWidth = width / (points - 1);

      // Start path
      const startY = height * marketPath[0];
      ctx.moveTo(0, startY);

      // Draw smooth curves through points
      for (let i = 0; i < points - 1; i++) {
        const x1 = i * segmentWidth;
        const y1 = height * marketPath[i];
        const x2 = (i + 1) * segmentWidth;
        const y2 = height * marketPath[i + 1];

        // Calculate control point for smooth curve
        const cpX = (x1 + x2) / 2;
        const cpY = (y1 + y2) / 2;

        ctx.quadraticCurveTo(x1, y1, cpX, cpY);
      }

      // Complete the path to the last point
      const lastX = (points - 1) * segmentWidth;
      const lastY = height * marketPath[points - 1];
      ctx.lineTo(lastX, lastY);
      ctx.stroke();

      // Draw finish line at the end
      ctx.strokeStyle = '#F4B400';
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 4]);
      ctx.beginPath();
      ctx.moveTo(lastX, 0);
      ctx.lineTo(lastX, height);
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw "FINISH" text at the end
      ctx.fillStyle = '#F4B400';
      ctx.font = 'bold 14px Inter';
      ctx.textAlign = 'center';
      ctx.save();
      ctx.translate(lastX, height / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText('FINISH', 0, -10);
      ctx.restore();

      // Smooth player position interpolation
      const targetProgress = progress / 100;
      const playerIndex = targetProgress * (points - 1);
      const lowerIndex = Math.floor(playerIndex);
      const upperIndex = Math.min(Math.ceil(playerIndex), points - 1);
      const fraction = playerIndex - lowerIndex;

      // Interpolate between two points for smooth movement
      const y1 = height * marketPath[lowerIndex];
      const y2 = height * marketPath[upperIndex];
      const playerX = playerIndex * segmentWidth;
      const playerY = y1 + (y2 - y1) * fraction;

      // Calculate current NAV based on position
      const navValue1 = marketPath[lowerIndex];
      const navValue2 = marketPath[upperIndex];
      const currentNavNormalized = navValue1 + (navValue2 - navValue1) * fraction;
      // Map from 0.2-0.8 range to ₹70-130 range
      const currentNAV = 70 + (currentNavNormalized - 0.2) * (60 / 0.6);
      setNav(Math.round(currentNAV * 100) / 100);

      // Draw player marker with glow effect
      ctx.shadowColor = '#F4B400';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#F4B400';
      ctx.beginPath();
      ctx.arc(playerX, playerY, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Player label
      ctx.fillStyle = '#1A1A1A';
      ctx.font = 'bold 12px Inter';
      ctx.textAlign = 'center';
      ctx.fillText('You', playerX, playerY - 15);

      animationFrame = requestAnimationFrame(draw);
    };

    draw();

    return () => cancelAnimationFrame(animationFrame);
  }, [time, progress]);

  const handleHold = () => {
    if (holdActionsLeft > 0) {
      soundManager.playHold();
      setCurrentEvent(null);
      setActionFeedback('💪 Holding steady!');
      setHoldActionsLeft((prev) => prev - 1);
    } else {
      setActionFeedback('🚫 No more Hold actions left!');
    }
  };

  const handleInvestMore = () => {
    if (investActionsLeft > 0) {
      soundManager.playInvest();
      
      // Fixed investment amount
      const investmentAmount = 500;
      
      // Calculate units based on current NAV (market price)
      const unitsToAdd = Math.round((investmentAmount / nav) * 10) / 10; // Round to 1 decimal
      
      setUnits((prev) => prev + unitsToAdd);
      setInvestedAmount((prev) => prev + investmentAmount);
      setCurrentEvent(null);
      
      // Smart feedback based on market conditions
      // Starting NAV is 100, so we compare to that
      const marketCondition = nav < 95 ? 'low' : nav > 105 ? 'high' : 'normal';
      
      if (marketCondition === 'low') {
        setActionFeedback(`🎯 Great timing! Added ${unitsToAdd} units at low price!`);
      } else if (marketCondition === 'high') {
        setActionFeedback(`💰 Added ${unitsToAdd} units at ₹${nav.toFixed(2)}`);
      } else {
        setActionFeedback(`🚀 Added ${unitsToAdd} units!`);
      }
      setInvestActionsLeft((prev) => prev - 1);
    } else {
      setActionFeedback('🚫 No more Invest actions left!');
    }
  };

  const handleExit = () => {
    soundManager.playExit();
    setGameActive(false);
    onGameEnd(units, time, true);
  };

  // Calculate portfolio metrics
  const currentValue = units * nav;
  const profitLoss = currentValue - investedAmount;
  const profitLossPercent = ((profitLoss / investedAmount) * 100).toFixed(2);
  const isProfit = profitLoss >= 0;

  return (
    <div className="h-screen flex flex-col bg-[#F7F9FA] p-6 relative">
      {/* Tutorial Overlay */}
      <AnimatePresence>
        {showTutorial && (
          <motion.div
            className="fixed inset-0 bg-black/80 flex items-center justify-center p-6 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6"
              initial={{ scale: 0.8, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 50 }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#0B6E69] to-[#16A34A] rounded-full flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-[22px] font-bold text-[#1A1A1A]">How to Play</h2>
              </div>
              
              <div className="bg-[#F7F9FA] rounded-2xl p-4 mb-4">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-8 h-8 bg-[#0B6E69] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Target className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-[14px] font-semibold text-[#1A1A1A] mb-1">Your Goal</p>
                    <p className="text-[13px] text-[#666]">Ride the yellow dot through market ups and downs to reach the finish line!</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 mb-5">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-white border-2 border-[#0B6E69] rounded-full flex items-center justify-center text-[14px] flex-shrink-0">💎</div>
                  <div>
                    <p className="text-[13px] font-semibold text-[#1A1A1A]">Hold <span className="text-[#0B6E69]">(6 times)</span></p>
                    <p className="text-[12px] text-[#666]">Stay invested through volatility</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-[#0B6E69] rounded-full flex items-center justify-center text-[14px] flex-shrink-0">💰</div>
                  <div>
                    <p className="text-[13px] font-semibold text-[#1A1A1A]">Invest More <span className="text-[#0B6E69]">(5 times)</span></p>
                    <p className="text-[12px] text-[#666]">Invest ₹500 - get more units when market is down!</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-white border-2 border-[#DC2626] rounded-full flex items-center justify-center text-[14px] flex-shrink-0">🚪</div>
                  <div>
                    <p className="text-[13px] font-semibold text-[#1A1A1A]">Exit Market</p>
                    <p className="text-[12px] text-[#666]">End game early and see results</p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-[#F4B400]/10 to-[#F4B400]/5 border border-[#F4B400] rounded-xl p-3 mb-5">
                <p className="text-[12px] text-[#1A1A1A]">
                  <span className="font-bold">💡 Pro Tip:</span> Use your actions wisely! Save "Invest" for market dips to get more units.
                </p>
              </div>

              <motion.button
                onClick={() => {
                  soundManager.playStart();
                  setShowTutorial(false);
                }}
                className="w-full h-[52px] bg-gradient-to-r from-[#0B6E69] to-[#16A34A] text-white rounded-full text-[16px] font-semibold shadow-lg"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Let's Ride! 🚀
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header with Progress */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-[24px] font-bold text-[#1A1A1A]">Ride the Market</h1>
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-sm">
            <Clock className="w-4 h-4 text-[#0B6E69]" />
            <span className="text-[14px] font-semibold text-[#1A1A1A]">{time}s</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-full p-1.5 shadow-sm mb-3">
          <div className="relative h-3 bg-[#F7F9FA] rounded-full overflow-hidden">
            <motion.div
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#0B6E69] to-[#16A34A]"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
            <div className="absolute top-0 right-0 h-full flex items-center pr-2">
              <span className="text-[10px] font-bold text-[#0B6E69]">{Math.round(progress)}%</span>
            </div>
          </div>
        </div>
        
        {/* Simplified Stats */}
        <div className="bg-gradient-to-br from-[#0B6E69] to-[#16A34A] rounded-2xl p-4 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-baseline gap-1">
              <IndianRupee className="w-4 h-4" />
              <span className="text-[24px] font-bold">{currentValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className={`flex items-center gap-1 px-3 py-1 rounded-full ${isProfit ? 'bg-[#F4B400]' : 'bg-[#FF6B6B]'}`}>
              <TrendingUp className={`w-3 h-3 ${!isProfit && 'rotate-180'}`} />
              <span className="text-[13px] font-bold">{isProfit ? '+' : ''}{profitLossPercent}%</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between text-[11px] opacity-90">
            <span>{units.toFixed(2)} units × ₹{nav.toFixed(2)}</span>
            <span>Invested: ₹{investedAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>
      </div>

      {/* Canvas Area */}
      <div className="flex-1 bg-white rounded-3xl shadow-sm p-4 mb-3 relative overflow-hidden min-h-0">
        <canvas
          ref={canvasRef}
          width={340}
          height={400}
          className="w-full h-full"
        />
      </div>

      {/* Event Message Footer */}
      <AnimatePresence>
        {currentEvent && (
          <motion.div
            className="bg-gradient-to-r from-[#0B6E69] to-[#16A34A] rounded-2xl p-3 mb-3 text-white shadow-lg"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl flex-shrink-0">{currentEvent.title.split(' ')[0]}</span>
              <div className="flex-1 min-w-0">
                <h3 className="text-[13px] font-semibold mb-0.5">
                  {currentEvent.title.substring(currentEvent.title.indexOf(' ') + 1)}
                </h3>
                <p className="text-[11px] opacity-90">
                  {currentEvent.message}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-2">
        <motion.button
          onClick={handleHold}
          disabled={holdActionsLeft === 0}
          className={`h-[50px] rounded-full text-[13px] font-semibold shadow-sm flex flex-col items-center justify-center relative ${
            holdActionsLeft === 0 
              ? 'bg-gray-200 border-2 border-gray-300 text-gray-400 cursor-not-allowed' 
              : 'bg-white border-2 border-[#0B6E69] text-[#0B6E69]'
          }`}
          whileHover={holdActionsLeft > 0 ? { scale: 1.05 } : {}}
          whileTap={holdActionsLeft > 0 ? { scale: 0.95 } : {}}
        >
          <span>💎 Hold</span>
          <span className={`text-[9px] mt-0.5 ${holdActionsLeft === 0 ? 'text-gray-400' : 'text-[#666]'}`}>
            {holdActionsLeft} left
          </span>
        </motion.button>
        <motion.button
          onClick={handleInvestMore}
          disabled={investActionsLeft === 0}
          className={`h-[50px] rounded-full text-[13px] font-semibold shadow-sm flex flex-col items-center justify-center relative ${
            investActionsLeft === 0 
              ? 'bg-gray-400 text-gray-200 cursor-not-allowed' 
              : 'bg-[#0B6E69] text-white'
          }`}
          whileHover={investActionsLeft > 0 ? { scale: 1.05 } : {}}
          whileTap={investActionsLeft > 0 ? { scale: 0.95 } : {}}
        >
          <span>💰 Invest</span>
          <span className={`text-[9px] mt-0.5 ${investActionsLeft === 0 ? 'text-gray-200' : 'opacity-90'}`}>
            {investActionsLeft} left
          </span>
        </motion.button>
        <motion.button
          onClick={handleExit}
          className="h-[50px] bg-white border-2 border-[#DC2626] text-[#DC2626] rounded-full text-[13px] font-semibold shadow-sm flex items-center justify-center"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <span>🚪 Exit</span>
        </motion.button>
      </div>

      {/* Action Feedback Toast */}
      <AnimatePresence>
        {actionFeedback && (
          <motion.div
            className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-white px-6 py-3 rounded-full shadow-xl border-2 border-[#0B6E69]"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
          >
            <p className="text-[14px] text-[#0B6E69] font-bold">{actionFeedback}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Volume Control */}
      <div className="absolute top-4 right-4">
        <button
          onClick={() => {
            setIsMuted(!isMuted);
            soundManager.setMutedState(!isMuted);
          }}
          className="bg-white rounded-full p-2 shadow-sm"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-[#0B6E69]" /> : <Volume2 className="w-4 h-4 text-[#0B6E69]" />}
        </button>
      </div>
    </div>
  );
}